import java.util.Scanner;
/**
 * Rectangle19
 */
public class Rectangle19 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Masukkan jumlah baris: ");
        int baris = sc.nextInt();
        System.out.print("Masukkan jumlah kolom: ");
        int kolom = sc.nextInt();

        for (int i = 1; i <= baris; i++) {          // outer loop:baris 
            for (int j = 1; j <= kolom; j++) {      // inner lopp:kolom
                System.out.print("#");
            }
            System.out.println();                   // pindah baris
        } 
        sc.close();
    }
}